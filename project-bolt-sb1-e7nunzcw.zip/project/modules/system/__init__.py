"""
System modules for WhatsApp UserBot
These are core modules that provide essential bot functionality
"""