"""
Example custom module
This is a template for creating custom modules
"""

from core.module_manager import BaseModule


class ExampleCustomModule(BaseModule):
    def __init__(self, name: str, config: dict = None):
        super().__init__(name, config)
        self.description = "Example custom module template"

    async def initialize(self, bot, logger):
        await super().initialize(bot, logger)
        self.logger.info(f"🔧 {self.name} custom module initialized")

    async def on_message(self, message: dict) -> bool:
        """Handle incoming messages"""
        text = message.get('text', '').strip().lower()
        
        # Example: respond to "custom test"
        if text == "custom test":
            response = "✅ Custom module is working!"
            await self.bot.send_message(message.get('chat'), response)
            return True
        
        return False

    async def on_command(self, command: str, args: list, message: dict) -> bool:
        """Handle commands"""
        if command == "custom":
            if args and args[0] == "info":
                info_text = """
🔧 **Custom Module Info**

This is an example custom module that demonstrates:
- Message handling
- Command processing  
- Configuration management
- Integration with the bot core

You can create your own modules by copying this template!
                """.strip()
                
                await self.bot.send_message(message.get('chat'), info_text)
                return True
            else:
                await self.bot.send_message(
                    message.get('chat'),
                    "🔧 Custom module loaded! Try: !custom info"
                )
                return True
        
        return False

    def get_commands(self) -> list:
        return ["custom"]

    def get_help(self) -> str:
        return "Example custom module - Template for creating your own modules"