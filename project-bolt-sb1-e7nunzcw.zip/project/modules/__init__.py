"""
Modules package for WhatsApp UserBot
Contains system modules and custom module management
"""