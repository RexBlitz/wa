"""
Core package for WhatsApp UserBot
Contains the main bot logic, configuration, and core functionality
"""

__version__ = "2.0.0"
__author__ = "WhatsApp UserBot Team"
__description__ = "Advanced WhatsApp UserBot with Telegram Bridge"