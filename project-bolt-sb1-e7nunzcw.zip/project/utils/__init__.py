"""
Utility functions for WhatsApp UserBot
"""